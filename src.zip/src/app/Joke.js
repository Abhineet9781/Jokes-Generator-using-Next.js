"use client";
import React from "react";
import Button from "./Button";

const Joke = () => {
  const [joke, setJoke] = React.useState("");

  const fetchApi = () => {
    fetch("https://v2.jokeapi.dev/joke/Programming?type=single")
      .then((res) => res.json())
      .then((data) => setJoke(data.joke));
  };

  return (
    <div className="flex flex-col items-center gap-12 p-6 w-full h-full ">
      {/* Button Section */}
      <div className="flex justify-center items-center bg-white shadow-md rounded-lg p-6 max-w-sm w-full">
        <Button callApi={fetchApi} />
      </div>

      {/* Joke Card Section */}
      {joke && (
        <div className="bg-white shadow-lg rounded-xl p-8 max-w-md w-full text-center border border-gray-200">
          <p className="text-gray-800 text-lg font-semibold">{joke}</p>
        </div>
      )}
    </div>
  );
};

export default Joke;
