import Joke from "./Joke";

function App() {
  return (
    <>
      <div className="flex flex-col items-center justify-start h-screen py-10 bg-gray-400">
        <h1 className="text-2xl font-bold text-center mb-4 text-white">
          Joke Generator Using React and Joke API
        </h1>

        <div className="flex justify-center items-start mt-6">
          <Joke />
        </div>
      </div>
    </>
  );
}

export default App;
