import React from "react";

const Button = (props) => {
  return(
<div className="ml-2 mr-2 mt-2 mb-2 rounded-[5px] font-semibold">
    <button onClick={props.callApi}>Click to generate</button>
    </div>
  )
};

export default Button;
